package org.example.intf;

public interface IPerson {

    String getName();

}
