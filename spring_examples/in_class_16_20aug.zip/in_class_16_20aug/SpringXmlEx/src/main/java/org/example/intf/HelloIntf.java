package org.example.intf;

public interface HelloIntf {

    String greet(String name);
    String greetByName(String greetstr);


}
