insert into emp(empid,empname,empsal) values(1,'Ram',5000);
insert into emp(empid,empname,empsal) values(2,'Shyam',10000);
insert into emp(empid,empname,empsal) values(3,'Sita',7000);