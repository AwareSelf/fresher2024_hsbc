package com.nama.springboot.restservicedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestservicedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
