package intf;

public interface ServiceIntf {

   String getServiceName();
   CourseIntf getCourse();
}
