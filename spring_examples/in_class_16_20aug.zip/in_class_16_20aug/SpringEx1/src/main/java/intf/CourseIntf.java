package intf;

public interface CourseIntf {

     String getCourseName();
     double getCoursePrice();

}
